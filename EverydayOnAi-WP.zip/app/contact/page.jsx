import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import Link from 'next/link';

export const metadata = { title: 'Contact — EverydayOnAI' };

export default function ContactPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen bg-white">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 py-16">
          <h1 className="text-3xl font-extrabold text-slate-900 mb-4">Contact Us</h1>
          <p className="text-slate-500 mb-6">
            For editorial inquiries, partnerships, or general questions, reach us at:
          </p>
          <a href="mailto:hello@everydayonai.com" className="text-blue-600 hover:underline font-medium text-lg">
            hello@everydayonai.com
          </a>
          <div className="mt-10">
            <Link href="/" className="text-sm text-blue-600 hover:underline">← Back to Home</Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
